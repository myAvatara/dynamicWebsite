const { response } = require('express');
const express = require('express');
const { route } = require('express/lib/router');
const Detail = require('../models/Detail');
const Slider = require('../models/Slider');
const Service = require('../models/Service')
const Contact =require('../models/contact');
const routes = express.Router();

// Index routing
routes.get("/",async(req,res)=>{
    const details = await Detail.findOne({"id":"6244dba0e64eea966543d361"});
    const slides = await Slider.find();
    const services = await Service.find();
    
    console.log(slides);
    // const details = await Detail.findOne({"id":"6244dba0e64eea966543d361"});
    // console.log(details);
    //Now we send this data as object in our home and views
    res.render("index",{
        details:details,
        slides:slides,
        services:services,
    });

    
})

// Contact form routing - process contact form
routes.post("/process_contact-form",async(req,res)=>{
    console.log('This form is submitted')
    console.log(req.body);
    // Now let's save the data to database and for that we'll need to create a model
    try {
        const data = await Contact.create(req.body);
        console.log(data);
        res.redirect('/');
    } catch (error) {
        console.log(error);
        console.log('/')
    }
})



module.exports = routes;
