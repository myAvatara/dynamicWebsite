const express = require("express");
const app = express();
const hbs = require('hbs');
const bodyParser = require('body-parser');
const routes =require('./routes/main');
const mongoose = require('mongoose');
const Detail = require('./models/Detail');
const Slider = require('./models/Slider');
const Service = require('./models/Service');


app.use(bodyParser.urlencoded({
    extended:true
}))//Using it we can parse data coming from cotact form as it is in json format, ynee ki iski madad se hum log data ko parse kar sakte h , iska matlab ki jo url encoded data a rha h vo data parse hokar hamara object miljayega in form of javascriptobject

// Abhi jo hum poora k poora form bjej reh h vo hamara urlencoded k roop me tha isliyea hum bodyparser.urlencoded use kr reh they or agar hum json k tarreke se data bhej reh hote to bodyparser.json krte


// Serving Static folder 
//If we want that our url should start from static instead of public then simply for that we pass an argument as /static , now to acess htat file or folder we simply need to give there path
app.use('/static',express.static('public'));


app.use('',routes);// It means here we do no fire any thing then it will automatically use routes
// app.use('user',routes);//It means here if we fire or deman to use routes then route would be fired
// app.use('gallery',routes); //It means if we fire or demand to use routes then route would be fired
// Hum log pehle hamesha apna body parse configure karenge then hum log route karenge


// Now let's configure out hbs or Template engine 
app.set('view engine','hbs');
app.set('views','views')
hbs.registerPartials('views/partials');


mongoose.connect("mongodb://localhost/dynamicwebsite").then(() => {
    console.log('Now we are connected to database');
    // Here we entered our dynamic data for navigatino Bar
    // Detail.create({
    //     brandName:"Venkatesh Technical Solutions",
    //     brandIconUrl:"https://www.bing.com/images/search?view=detailV2&ccid=6Y5YMLSq&id=E9913122271BC6E9B42461D7C02903D22321427B&thid=OIP.6Y5YMLSq7rbR0jYyM5TuxgHaHa&mediaurl=https%3A%2F%2Fwww.pngarts.com%2Ffiles%2F2%2FLetter-V-Transparent-Background-PNG.png&exph=512&expw=512&q=3D+V++Logo+without+background&simid=607996300850513819&form=IRPRST&ck=A896E09D8472C0D6E4DAF75945A5F898&selectedindex=26&ajaxhist=0&ajaxserp=0&vt=0&sim=11",
    //     links:[
    //         {
    //         label:"Home",
    //         url:"/"
    //         },
    //         {
    //          label:"Services",
    //          url:"/services"
    //         },
    //         {
    //             label:"Gallery",
    //             url:"/gallery"
    //         },
    //         {
    //             label:"About",
    //             url:"/about"
    //         },
    //         {
    //             label:"Contact",
    //             url:"/contact-us"
    //         }
    //     ]
    // })
    
    
    // Slider.create([
    //     {
    //       title:'Welcome to Vishnu Technical Solutions',
    //       subTitle:'We provide you Best materila to make your programming Journey awesome' ,
    //       imageUrl:'/static/images/programming1.png'
    //     },
    //     {
    //       title:'Welcome to Vishnu Technical Solutions',
    //       subTitle:'Here we provide your the best Content material for your studies' ,
    //       imageUrl:'/static/images/programming2.png'
    //     },
    //     {
    //       title:'Welcome to Vishnu Technical Solutions',
    //       subTitle:'Our focus is to make you easily understand all programming related stuff so that you can have a successfull carrer',
    //       imageUrl:'/static/images/programming3.png'  
    //     },
    // ])

    // Service.create([
    //     {
    //         xmlns:'http://www.w3.org/2000/svg',
    //         path:'M322.1 252v-1l-51.2-65.8s-12 1.6-25 15.1c-9 9.3-242.1 239.1-243.4 240.9-7 10 1.6 6.8 15.7 1.7.8 0 114.5-36.6 114.5-36.6.5-.6-.1-.1.6-.6-.4-5.1-.8-26.2-1-27.7-.6-5.2 2.2-6.9 7-8.9l92.6-33.8c.6-.8 88.5-81.7 90.2-83.3zm160.1 120.1c13.3 16.1 20.7 13.3 30.8 9.3 3.2-1.2 115.4-47.6 117.8-48.9 8-4.3-1.7-16.7-7.2-23.4-2.1-2.5-205.1-245.6-207.2-248.3-9.7-12.2-14.3-12.9-38.4-12.8-10.2 0-106.8.5-116.5.6-19.2.1-32.9-.3-19.2 16.9C250 75 476.5 365.2 482.2 372.1zm152.7 1.6c-2.3-.3-24.6-4.7-38-7.2 0 0-115 50.4-117.5 51.6-16 7.3-26.9-3.2-36.7-14.6l-57.1-74c-5.4-.9-60.4-9.6-65.3-9.3-3.1.2-9.6.8-14.4 2.9-4.9 2.1-145.2 52.8-150.2 54.7-5.1 2-11.4 3.6-11.1 7.6.2 2.5 2 2.6 4.6 3.5 2.7.8 300.9 67.6 308 69.1 15.6 3.3 38.5 10.5 53.6 1.7 2.1-1.2 123.8-76.4 125.8-77.8 5.4-4 4.3-6.8-1.7-8.2z',
    //         title:'Provide best courses',
    //         description:'We provide courses that helps our students in learning and in placement',
    //         linkText:'Check',
    //         link:'https://www.venkateshsolutions.com',
    //         linkText2:'Support',
    //         link2:'https://www.venkateshsolutions.com',
    
    //     },
    //     {
    //         xmlns:'http://www.w3.org/2000/svg',
    //         path:'M103.3 344.3c-6.5-14.2-6.9-18.3 7.4-23.1 25.6-8 8 9.2 43.2 49.2h.3v-93.9c1.2-50.2 44-92.2 97.7-92.2 53.9 0 97.7 43.5 97.7 96.8 0 63.4-60.8 113.2-128.5 93.3-10.5-4.2-2.1-31.7 8.5-28.6 53 0 89.4-10.1 89.4-64.4 0-61-77.1-89.6-116.9-44.6-23.5 26.4-17.6 42.1-17.6 157.6 50.7 31 118.3 22 160.4-20.1 24.8-24.8 38.5-58 38.5-93 0-35.2-13.8-68.2-38.8-93.3-24.8-24.8-57.8-38.5-93.3-38.5s-68.8 13.8-93.5 38.5c-.3.3-16 16.5-21.2 23.9l-.5.6c-3.3 4.7-6.3 9.1-20.1 6.1-6.9-1.7-14.3-5.8-14.3-11.8V20c0-5 3.9-10.5 10.5-10.5h241.3c8.3 0 8.3 11.6 8.3 15.1 0 3.9 0 15.1-8.3 15.1H130.3v132.9h.3c104.2-109.8 282.8-36 282.8 108.9 0 178.1-244.8 220.3-310.1 62.8zm63.3-260.8c-.5 4.2 4.6 24.5 14.6 20.6C306 56.6 384 144.5 390.6 144.5c4.8 0 22.8-15.3 14.3-22.8-93.2-89-234.5-57-238.3-38.2zM393 414.7C283 524.6 94 475.5 61 310.5c0-12.2-30.4-7.4-28.9 3.3 24 173.4 246 256.9 381.6 121.3 6.9-7.8-12.6-28.4-20.7-20.4zM213.6 306.6c0 4 4.3 7.3 5.5 8.5 3 3 6.1 4.4 8.5 4.4 3.8 0 2.6.2 22.3-19.5 19.6 19.3 19.1 19.5 22.3 19.5 5.4 0 18.5-10.4 10.7-18.2L265.6 284l18.2-18.2c6.3-6.8-10.1-21.8-16.2-15.7L249.7 268c-18.6-18.8-18.4-19.5-21.5-19.5-5 0-18 11.7-12.4 17.3L234 284c-18.1 17.9-20.4 19.2-20.4 22.6z',
    //         title:'Provide best courses',
    //         description:'We provide courses that helps our students in learning and in placement',
    //         linkText:'Check',
    //         link:'https://www.venkateshsolutions.com',
    //         linkText2:'Support',
    //         link2:'https://www.venkateshsolutions.com',
    //     },
    //     {
    //         xmlns:'http://www.w3.org/2000/svg',
    //         path:'M159.7 237.4C108.4 308.3 43.1 348.2 14 326.6-15.2 304.9 2.8 230 54.2 159.1c51.3-70.9 116.6-110.8 145.7-89.2 29.1 21.6 11.1 96.6-40.2 167.5zm351.2-57.3C437.1 303.5 319 367.8 246.4 323.7c-25-15.2-41.3-41.2-49-73.8-33.6 64.8-92.8 113.8-164.1 133.2 49.8 59.3 124.1 96.9 207 96.9 150 0 271.6-123.1 271.6-274.9.1-8.5-.3-16.8-1-25z',
    //         title:'Provide best courses',
    //         description:'We provide courses that helps our students in learning and in placement',
    //         linkText:'Check',
    //         link:'https://www.venkateshsolutions.com',
    //         linkText2:'Support',
    //         link2:'https://www.venkateshsolutions.com',
    //     },

       
    // ])

}).catch((error) => {
    console.log('Some error has occured'+ error)
});;

app.get("/",(req,res)=>{
    res.send("Here our we are working properly")
})


const port = 9000  ;
app.listen(port,()=>{
    console.log('Here our server is running properly');
})
