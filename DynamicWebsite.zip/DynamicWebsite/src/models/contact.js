const mongoose = require('mongoose');
const { modelName } = require('./Detail');
const contact = mongoose.Schema({
    email:String,
    phone:String,
    query:String,
});


module.exports = mongoose.model('queries',contact);
