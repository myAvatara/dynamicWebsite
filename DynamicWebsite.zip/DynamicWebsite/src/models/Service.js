const mongoose = require("mongoose");

const Service = mongoose.Schema({
    xmlns:String,
    path:String,
    title:String,
    description:String,
    linkText:String,
    link:String,
    linkText2:String,
    link2:String,
})

module.exports = mongoose.model('service',Service);